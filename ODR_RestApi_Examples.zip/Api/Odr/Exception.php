<?php
class Api_Odr_Exception extends Exception
{
}